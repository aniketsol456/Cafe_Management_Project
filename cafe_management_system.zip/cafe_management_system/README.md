#Cafe Management Project

The Cafe Management System has been developed to automate various operations within a cafe, offering efficiency and user-friendliness for both customers and staff. Its purpose is to enhance productivity, elevate customer service, and streamline daily management tasks.

Functionalities of this Project:-
1. Shift Schedule
2. Role based access
3. Customer Database
4. Feedback and Reviews
5. Order Management , Processing and Tracking
6. Menu Management

GitHub Repository Link :- https://github.com/aniketsol456/cafe_management_project/tree/main/cafe_management_system
