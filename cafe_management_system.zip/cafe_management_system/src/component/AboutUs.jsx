import React from 'react';
import Footer from './Footer';

const AboutUs = () => {
  return (
    <><div classname ="About">
    </div>
    <Footer/>
    </>
  )
}

export default AboutUs
